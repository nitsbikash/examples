jQuery-WeekPicker
=================

A simple week picker for jquery ui. 
