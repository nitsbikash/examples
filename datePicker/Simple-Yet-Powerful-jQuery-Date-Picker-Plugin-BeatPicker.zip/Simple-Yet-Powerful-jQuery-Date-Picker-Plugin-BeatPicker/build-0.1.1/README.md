BeatPicker
==========

Simple and powerful date picker widget for jQuery
## Dependencies
* jQuery1.8.0+
* BeatPicker.min.js
* BeatPicker.min.css

## Links
* [Download page](http://act1gmr.github.io/BeatPicker/)
* [Live demo](http://act1gmr.github.io/BeatPicker/demos.html)
* [Docs](http://act1gmr.github.io/BeatPicker/docs.html)
