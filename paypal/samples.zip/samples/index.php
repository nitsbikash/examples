<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>PayPal Adaptive Payments SDK - API Calls sample</title>
<link href="Common/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
	<div id="wrapper">
		<img src="https://devtools-paypal.com/image/bdg_payments_by_pp_2line.png"/>
		<center>
			<h3>
				<b>API Calls Sample - Home</b>
			</h3>
		</center>
		<?php
		include 'Common/menu.html';
		?>
	</div>
</body>
</html>
