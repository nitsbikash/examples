<?php
ob_start();
session_start();

$hostname="localhost";
$dbname="uploadcsv";
$username="root";
$password="root";


$link=mysql_connect($hostname,$username,$password) or die("Error in Connection. Check Server Configuration.");
mysql_select_db($dbname,$link) or die("Database not Found. Please Create the Database.");

?>
<?php 
if(isset($_POST['submit']))
{
    //$handle = fopen('student.csv',"r");
	
	if($_FILES['file_image']['tmp_name']!='')
    {
		$target_path="files/";
		$userfile_name = $_FILES['file_image']['name'];
		$userfile_tmp = $_FILES['file_image']['tmp_name'];
		$img_name =time().$userfile_name;
		$img=$target_path.$img_name;
		move_uploaded_file($userfile_tmp, $img);
    }
    
    $handle = fopen($target_path.$img_name,"r"); 
  
    //echo "hello";
    //exit;
    $i=0;
    
    while (($data = fgetcsv($handle, 2, ",")) !== FALSE) 
    {
		
      
        $name = mysql_real_escape_string(trim($data[0]));
        $email = mysql_real_escape_string(trim($data[1]));


        $import="INSERT INTO `students` SET `name` = '".$name."', `email` = '".$email."'";
        echo $import."<br>";
        //mysql_query($import) or die(mysql_error());
	   
    }
	 
    fclose($handle);
	
	
}
?>
<!DOCTYPE html>
<html>
    
    <head>
        <title>Upload Student By CSV</title>
        <!-- Bootstrap -->
        
    </head>
    
    <body>
         <form class="form-horizontal" method="post" action="" enctype="multipart/form-data">              
                                      <fieldset>
                                        <legend>Upload Students By CSV</legend>
                                       
                                        <div class="control-group">
                                        <label class="control-label" for="focusedInput">Upload CSV</label>
                                        <div class="controls">
                                        <input id="file_image" name="file_image" type="file" >
                                        </div>
					 					</div>
                                        
                                        <div class="form-actions" style="margin-top:120px;">
                                          <button type="submit" class="btn btn-primary"  name="submit">Upload</button>
                                        </div>
                                      </fieldset>
                                    </form>
    </body>

</html>
