<html>
    <head>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
        <link rel="stylesheet" href="http://code.jquery.com/ui/1.11.0/themes/smoothness/jquery-ui.css">
<script src="http://code.jquery.com/ui/1.11.0/jquery-ui.js"></script>
       <script>
           $(function(){
               jQuery('#search_user').autocomplete({
				 minLength :1,
				 source: function(request, response) {
				   var url='user-autosuggest.php';
										$.getJSON(url, response );
				 }, 
				 select: function(event, ui) {
				console.log(ui.item.link);
				 },
						change: function(event, ui ) {
					  
					 }
				
				});
           })
       </script>    
           
    </head>
    <body>
        <input type="text" value="" name="search" id="search_user" />
    </body>
</html>