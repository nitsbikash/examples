<?php

 
	$temp=array(
            array('label'=>'Bikash','link'=>'1'),
            array('label' => 'John','link'=>'2'))    ;
	
	echo json_encode($temp);
	exit;
 ?>